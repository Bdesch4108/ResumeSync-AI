# ResumeSync AI Backend

This is a Flask-based backend for ResumeSync AI, providing endpoints to customize resumes and generate cover letters using OpenAI's GPT-4.

## Endpoints

- POST /customize-resume
- POST /generate-cover-letter

## Setup

1. Clone the repo
2. Add your OpenAI API key to `.env`
3. Run `pip install -r requirements.txt`
4. Start the server with `python app.py`
