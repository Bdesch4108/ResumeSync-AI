# ResumeSync AI Backend

This is the backend Flask API for customizing resumes and generating cover letters using OpenAI.